module.exports = {
  Token: "",
  owner: "7466190629",
};